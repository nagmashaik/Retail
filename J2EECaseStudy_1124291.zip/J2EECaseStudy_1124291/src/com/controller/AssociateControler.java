package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.associate.Associate;
import com.demo.service.AssociateService;

/**
 * Servlet implementation class AssociateControler
 */
public class AssociateControler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssociateControler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub'
		System.out.println("working");
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	
		System.out.println("AssociateController::doPost invoked");
		String action=request.getParameter("action");
		System.out.println("User action received by controller="+action);
		
		
		if("searchAssociate".equals(action)){
			String search_id=request.getParameter("empid");
			int id=Integer.parseInt(search_id);
			AssociateService service=new AssociateService();
			ArrayList<Associate> al=service.SearchAssociate(id);
			request.setAttribute("associate",al);
			
			RequestDispatcher req=request.getRequestDispatcher("viewAssociateList.jsp");
			req.forward(request, response);
		
		}
		
		else if("addAssociate".equals(action)){
			Associate aso=new Associate();
			
			//System.out.println(request.getParameter("customerName"));
			
			aso.setAssociate_Id(Integer.parseInt(request.getParameter("Empid")));
			aso.setAssociate_Name(request.getParameter("ename"));
			aso.setAssociate_Gender(request.getParameter("gender"));
			aso.setAssociate_Branch(request.getParameter("ILPBatch"));
			aso.setAssociate_Ilp(request.getParameter("ILPLocation"));
			aso.setAssociate_Skills(request.getParameter("Skillset"));
			AssociateService service=new AssociateService();
			int status=service.addAssociate(aso);
			
		
			request.setAttribute("associate",status);
			RequestDispatcher req=request.getRequestDispatcher("createResult.jsp");
			req.forward(request,response);
		}
			
				
		
		else if("updateAssociate".equals(action)){
			String updateid=request.getParameter("empid");
			int up_id=Integer.parseInt(updateid);
			
			Associate asso=new Associate();
			asso.setAssociate_Skills(request.getParameter("skillset"));
			AssociateService service=new AssociateService();
			ArrayList<Associate> al=service.updateAssociate(up_id,asso);
			request.setAttribute("associate",al);
			RequestDispatcher req=request.getRequestDispatcher("viewAssociateList.jsp");
			req.forward(request, response);
			
			}
		
			else if("deleteAssociate".equals(action)){
			String delid=request.getParameter("empid");
			int de_id=Integer.parseInt(delid);
			AssociateService service=new AssociateService();
			service.deleteAssociate(de_id);
			
			RequestDispatcher req=request.getRequestDispatcher("viewDeletedList.jsp");
			req.forward(request, response);
			
			
			
		
	}

	}
	
}

