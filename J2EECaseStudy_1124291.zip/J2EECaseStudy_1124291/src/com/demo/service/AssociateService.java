package com.demo.service;

import java.util.ArrayList;

import com.demo.associate.Associate;
import com.demo.dao.AssociateDAO;

public class AssociateService {
	
	
	public ArrayList<Associate> SearchAssociate(int associate_Id){
		AssociateDAO c=new AssociateDAO();
		ArrayList<Associate> cl=c.SearchAssociate(associate_Id);
		return cl;
		
	}
	
	
	public ArrayList<Associate> updateAssociate(int associate_Id,Associate as){
		
		AssociateDAO c=new AssociateDAO();
		ArrayList<Associate> cl=c.updateAssociate(associate_Id,as);
		return cl;
		
	}
public int addAssociate(Associate a){
	
	AssociateDAO c=new AssociateDAO();
	return c.addAssociate(a);
}



public void deleteAssociate(int associate_Id)
{
	AssociateDAO c=new AssociateDAO();
	c.deleteAssociate(associate_Id);
	
	}
}
